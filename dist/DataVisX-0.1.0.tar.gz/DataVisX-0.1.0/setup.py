from setuptools import setup, find_packages

setup(
    name='DataVisX',
    version='0.1.0',
    description='Descripción de mi paquete',
    author='Rodigo Pérez - Gabriela Segura - Javier Gallardo - Amirah luna izidine',
    packages=find_packages(),
    install_requires=[
        # Lista de dependencias necesarias para tu paquete (si tienes alguna)
    ]
)
